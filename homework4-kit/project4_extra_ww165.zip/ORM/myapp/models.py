# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

import django.conf

django.conf.settings.configure(
    DATABASES = {
    'default': {  # development setting
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'ACC_BBALL',
        'USER': 'postgres',
        'PASSWORD': 'passw0rd',
        'HOST': '127.0.0.1',
        'PORT': '5432',
    }
    },
    INSTALLED_APPS = ("myapp",),
    SECRET_KEY = 'not telling',
)

django.setup()

class Color(models.Model):
    color_id = models.AutoField(db_column='COLOR_ID', primary_key=True)  # Field name made lowercase.
    name = models.TextField(db_column='NAME')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'COLOR'


class Player(models.Model):
    player_id = models.AutoField(db_column='PLAYER_ID', primary_key=True)  # Field name made lowercase.
    team = models.ForeignKey('Team', models.DO_NOTHING, db_column='TEAM_ID')  # Field name made lowercase.
    uniform_num = models.IntegerField(db_column='UNIFORM_NUM')  # Field name made lowercase.
    first_name = models.TextField(db_column='FIRST_NAME')  # Field name made lowercase.
    last_name = models.TextField(db_column='LAST_NAME')  # Field name made lowercase.
    mpg = models.IntegerField(db_column='MPG')  # Field name made lowercase.
    ppg = models.IntegerField(db_column='PPG')  # Field name made lowercase.
    rpg = models.IntegerField(db_column='RPG')  # Field name made lowercase.
    apg = models.IntegerField(db_column='APG')  # Field name made lowercase.
    spg = models.FloatField(db_column='SPG')  # Field name made lowercase.
    bpg = models.FloatField(db_column='BPG')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'PLAYER'


class State(models.Model):
    state_id = models.AutoField(db_column='STATE_ID', primary_key=True)  # Field name made lowercase.
    name = models.TextField(db_column='NAME')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'STATE'


class Team(models.Model):
    team_id = models.AutoField(db_column='TEAM_ID', primary_key=True)  # Field name made lowercase.
    name = models.TextField(db_column='NAME')  # Field name made lowercase.
    state = models.ForeignKey(State, models.DO_NOTHING, db_column='STATE_ID')  # Field name made lowercase.
    color = models.ForeignKey(Color, models.DO_NOTHING, db_column='COLOR_ID')  # Field name made lowercase.
    wins = models.IntegerField(db_column='WINS')  # Field name made lowercase.
    losses = models.IntegerField(db_column='LOSSES')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TEAM'
