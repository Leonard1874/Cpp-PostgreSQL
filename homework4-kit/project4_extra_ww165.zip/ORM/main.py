import os
import django
from myapp.models import *
    
def query1(use_mpg, min_mpg, max_mpg,
           use_ppg, min_ppg, max_ppg,
           use_rpg, min_rpg, max_rpg,
           use_apg, min_apg, max_apg,
           use_spg, min_spg, max_spg,
           use_bpg, min_bpg, max_bpg):
    r1 = Player.objects.all()
    if use_mpg > 0:
        r1 = r1.filter(mpg__gte = min_mpg, mpg__lte = max_mpg)
    if use_ppg > 0:
        r1 = r1.filter(ppg__gte = min_ppg, ppg__lte = max_ppg)
    if use_rpg > 0:
        r1 = r1.filter(rpg__gte = min_rpg, rpg__lte = max_rpg)
    if use_apg > 0:
        r1 = r1.filter(apg__gte = min_apg, apg__lte = max_apg)
    if use_spg > 0:
        r1 = r1.filter(spg__gte = min_spg, spg__lte = max_spg)
    if use_bpg > 0:
        r1 = r1.filter(bpg__gte = min_bpg, bpg__lte = max_bpg)
    print("PLAYER_ID TEAM_ID UNIFORM_NUM FIRST_NAME LAST_NAME MPG PPG RPG APG SPG BPG")
    for p in r1:
        print(str(p.player_id) + ' ' + str(p.team.team_id) + ' ' + str(p.uniform_num) + ' ' + p.first_name + ' '+ p.last_name + ' ' + str(p.mpg) + ' ' + str(p.ppg) + ' ' + str(p.rpg) + ' ' + str(p.apg) + ' ' + str(p.spg) + ' ' + str(p.bpg))

def query2(team_color):
    r2 = Team.objects.all()
    r2 = r2.filter(color__name = team_color)
    print("NAME")
    for p in r2:
        print(p.name)

def query3(team_name):
    r3 = Player.objects.all()
    r3 = r3.filter(team__name = team_name)
    r3 = r3.order_by('-ppg')
    print("FIRST_NAME LAST_NAME")
    for p in r3:
        print(p.first_name + ' '+ p.last_name)

def query4(state,color):
    r4 = Player.objects.all()
    r4 = r4.filter(team__state__name = state, team__color__name = color)
    print("FIRST_NAME LAST_NAME UNIFORM_NUM")
    for p in r4:
        print(p.first_name + ' '+ p.last_name + ' ' + str(p.uniform_num))

def query5(num_wins):
    r5 = Player.objects.all()
    r5 = r5.filter(team__wins__gt = num_wins)
    print("FIRST_NAME LAST_NAME WINS")
    for p in r5:
        print(p.first_name + ' '+ p.last_name + ' ' + str(p.team.wins))
    
query1(1,29,34,1,5,11,1,5,11,1,1,5,1,1.2,1.7,1,0.1,0.4)
query2("Red")
query3("NCSU")
query4("NC","DarkBlue")
query5(12)
